﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_StrategyPattern
{
    interface IPersonComparer : IComparer<Person>
    {
        
    }
}
