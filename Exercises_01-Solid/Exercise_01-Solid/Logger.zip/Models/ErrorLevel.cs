﻿namespace Logger.Models.Contracts
{
    public enum ErrorLevel
    {
        INFO,
        WARNING,
        CRITICAL,
        ERROR,
        FATAL
    }
}