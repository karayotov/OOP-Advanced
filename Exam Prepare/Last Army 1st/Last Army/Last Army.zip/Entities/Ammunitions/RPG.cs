﻿public class RPG : Ammunition
{
    private const double WEIGHT = 17.1d;

    public override double Weight => WEIGHT;

}