﻿public class Knife : Ammunition
{
    private const double WEIGHT = 0.4d;

    public override double Weight => WEIGHT;
}