﻿public class Gun : Ammunition
{
    private const double WEIGHT = 1.4d;

    public override double Weight => WEIGHT;
}