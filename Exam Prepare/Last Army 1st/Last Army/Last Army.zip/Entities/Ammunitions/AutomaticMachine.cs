﻿public class AutomaticMachine : Ammunition
{
    private const double WEIGHT = 6.3d;

    public override double Weight => WEIGHT;
}