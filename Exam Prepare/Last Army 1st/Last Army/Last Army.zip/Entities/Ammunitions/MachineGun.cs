﻿public class MachineGun : Ammunition
{
    private const double WEIGHT = 10.6d;

    public override double Weight => WEIGHT;

}