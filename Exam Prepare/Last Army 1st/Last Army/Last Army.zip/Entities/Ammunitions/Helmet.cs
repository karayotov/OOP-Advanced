﻿public class Helmet : Ammunition
{
    private const double WEIGHT = 2.3d;

    public override double Weight => WEIGHT;

}