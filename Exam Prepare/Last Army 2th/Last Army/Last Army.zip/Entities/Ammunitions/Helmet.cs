﻿public class Helmet : Ammunition
{
    private const double WEIGHT = 2.3;

    public override double Weight => WEIGHT;
}