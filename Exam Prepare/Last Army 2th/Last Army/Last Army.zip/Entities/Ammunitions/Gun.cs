﻿
public class Gun : Ammunition
{
    private const double WEIGHT = 1.4;

    public override double Weight => WEIGHT;
}