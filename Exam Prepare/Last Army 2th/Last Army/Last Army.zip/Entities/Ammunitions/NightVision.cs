﻿
public class NightVision : Ammunition
{
    private const double WEIGHT = 0.8;

    public override double Weight => WEIGHT;
}