﻿public class RPG : Ammunition
{
    private const double WEIGHT = 17.1;

    public override double Weight => WEIGHT;
}