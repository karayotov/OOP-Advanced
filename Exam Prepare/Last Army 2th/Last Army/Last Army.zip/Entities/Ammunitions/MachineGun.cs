﻿
public class MachineGun : Ammunition
{
    private const double WEIGHT = 10.6;

    public override double Weight => WEIGHT;
}