﻿
public class AutomaticMachine : Ammunition
{
    private const double WEIGHT = 6.3;

    public override double Weight => WEIGHT;
}