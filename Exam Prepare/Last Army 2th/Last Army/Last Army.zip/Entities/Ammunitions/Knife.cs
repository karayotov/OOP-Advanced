﻿
public class Knife : Ammunition
{
    private const double WEIGHT = 0.4;

    public override double Weight => WEIGHT;
}