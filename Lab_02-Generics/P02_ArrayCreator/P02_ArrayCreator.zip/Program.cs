﻿using System;

namespace P02_ArrayCreator
{
    class Program
    {
        static void Main(string[] args)
        {
            var arr = ArrayCreator.Create<string>(4, "select");

            Console.WriteLine();

        }
    }
}