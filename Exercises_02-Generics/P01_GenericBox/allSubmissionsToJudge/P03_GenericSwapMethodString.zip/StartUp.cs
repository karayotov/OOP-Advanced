﻿using System;
using System.Collections.Generic;

public class Program
{
    static void Main(string[] args)
    {
        //SolutionManager.GenericBox();
        //SolutionManager.GenericBoxOfStrings();
        //SolutionManager.GenericBoxOfInteger();
        SolutionManager.GenericSwapMethodString();
        //SolutionManager.GenericSwapMethodInteger();

    }
}