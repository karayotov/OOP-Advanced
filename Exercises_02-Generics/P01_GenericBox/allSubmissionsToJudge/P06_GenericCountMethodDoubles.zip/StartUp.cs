﻿using System;
using System.Collections.Generic;

public class Program
{
    static void Main(string[] args)
    {
        //SolutionManager.GenericBox(); //P00
        //SolutionManager.GenericBoxOfStrings(); //P01
        //SolutionManager.GenericBoxOfInteger();  //P02
        //SolutionManager.GenericSwapMethodString();  //P03
        //SolutionManager.GenericSwapMethodInteger();  //P04
        //SolutionManager.GenericCountMethodStrings();  //P05
        SolutionManager.GenericCountMethodDoubles();  //P06

    }
}